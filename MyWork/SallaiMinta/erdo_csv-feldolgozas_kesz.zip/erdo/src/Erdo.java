public class Erdo {
    int id;
    String nev;
    String tipus;
    int meret;
    String terulet;
    String orszag;
    boolean vedett;
}
