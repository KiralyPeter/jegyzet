import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame extends JFrame {
    String[] studentArray = {
        "Pali",
        "Mari",
        "Dani",
        "Árpi",
        "Gazsi",
        "Lali",
        "Peti",
        "Imi",
        "Andi",
        "Timi"
    };

    final int MAX_STUDENTS = studentArray.length;
    final int NUM_OF_STUDENT = 4;

    JButton autoButton = new JButton("Automatikusa");
    JPanel panel = new JPanel();
    JButton markButton = new JButton("Jelöl");

    JCheckBox[] boxes = new JCheckBox[MAX_STUDENTS];

    public MainFrame() {
        
        initComponents();

        
        setLayout(new BorderLayout());

        add(autoButton, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
        add(markButton, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setVisible(true);
    }
    
    public void initComponents() {
        panel.setLayout(new GridLayout(0, 4));
        for (int i = 0; i < boxes.length; i++) {
            boxes[i] = new JCheckBox( (i+1) + ") " 
                + studentArray[i]);
            panel.add(boxes[i]);
            boxes[i].addItemListener(e -> changeItem());
        }
        markButton.setEnabled(false);
        markButton.addActionListener(e -> startMark());
    }
    private void changeItem() {
        System.out.println("kattintás volt");
        int count = 0;
        for (int i = 0; i < boxes.length; i++) {
            if(boxes[i].isSelected()) {
                count++;
            }
        }
        markButton.setEnabled(count == NUM_OF_STUDENT);        
    }
    private void startMark() {
        System.out.println("meg vannak");
    }
}